package com.example.myapplication.viewmodel;

import android.content.Context;

import com.example.myapplication.model.UserModel;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.library.baseAdapters.BR;

public class UserViewModel extends BaseObservable {


    private String name;
    private String phone;
    private Context mContext;

    public UserViewModel(Context context) {
        this.mContext = context;
    }

    public UserViewModel(UserModel userModel) {
        this.name = name;
        this.phone = phone;
    }


    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);

    }
    @Bindable
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        notifyPropertyChanged(BR.phone);

    }
}
